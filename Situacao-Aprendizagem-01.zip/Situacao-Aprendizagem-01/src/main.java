import java.util.Scanner;

public class main {

	public static void main(String [] args) {
		
		Scanner objScanner= new Scanner(System.in);
		DadosPessoais objdadosPessoais = new DadosPessoais();
		DadosContato objdadosContato = new DadosContato();
		DadosEndereco objdadosEndereco = new DadosEndereco();
		
		System.out.println("###---- BEM VINDO----###");
		System.out.println("NOME: ");
		objdadosPessoais.setNome(objScanner.next());
		
		System.out.println("SOBRENOME: ");
		objdadosPessoais.setSobrenome(objScanner.next());
		
		System.out.println("DATA DE NASCIMENTO: ");
		objdadosPessoais.setDataNascimento(objScanner.next());
		
		System.out.println("GENERO: ");
		objdadosPessoais.setGenero(objScanner.next());
		
		System.out.println("DIGITE SEU EMAIL: ");
		objdadosContato.setEmail(objScanner.next());
		
		System.out.println("DIGITE SEU TELEFONE: ");
		objdadosContato.setTelefone(objScanner.next());
		
		System.out.println("DIGITE SEU CEP: ");
		objdadosEndereco.setCep(objScanner.next());
		
		System.out.println("DIGITE SEU LAGRADOURO: ");
		objdadosEndereco.setLagradouro(objScanner.next());
		
		System.out.println("DIGITE O N�MERO DA CASA: ");
		objdadosEndereco.setNumero(objScanner.next());
		
		System.out.println("DIGITE SEU BAIRRO: ");
		objdadosEndereco.setBairro(objScanner.next());
		
		System.out.println("DIGITE SEU CIDADE: ");
		objdadosEndereco.setCidade(objScanner.next());
		
		System.out.println("DIGITE SEU ESTADO: ");
		objdadosEndereco.setEstado(objScanner.next());
		
		System.out.println("OBRIGADO POR UTILIZAR O PROGRAMA");
	}
}
