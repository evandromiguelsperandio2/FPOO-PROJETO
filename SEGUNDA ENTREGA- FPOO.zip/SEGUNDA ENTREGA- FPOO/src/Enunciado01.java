
public class Enunciado01 {

	public void exibirMaior(int n1, int n2) {
		
		if(n1 > n2) {
			System.out.println("N1 � MAIOR QUE N2");
		}else {
			System.out.println("N2 � MAIOR QUE N1");
		}
			
	}
	
}
