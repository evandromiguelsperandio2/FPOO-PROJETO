
public class Enunciado02 {
	
	public void exibirMaior(int n1, int n2, int n3) {
		
		if (n1 > n2) {
			if (n2 > n3) {
				System.out.println("N1 � MAIOR QUE N2 E N3");
			}
		}
		
		if (n2 > n1) {
			if (n2 > n3) {
				System.out.println("N2 � MAIOR QUE N1 E N3");
			}
		}
		
		if (n3 > n1) {
			if (n3 > n2) {
				System.out.println("N3 � MAIOR QUE N1 E N2");
			}
		}
		
		
		
		
		
		
		
	}

}
