import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		Scanner objScanner = new Scanner(System.in);
		//Enunciado01 objEnunciado01 = new Enunciado01();
		//Enunciado01_1 objEnunciado01_1 = new Enunciado01_01();
		//Enunciado02 objEnunciado02 = new Enunciado02();
		//Enunciado03 objEnunciado03 = new Enunciado03();
		//Enunciado04 objEnunciado04 = new Enunciado04();
		//Enunciado05 objEnunciado05 = new Enunciado05();
		
		
		
		//Enunciado01_1
		
		/*
		System.out.println("INFORME O PRIMEIRO N�MERO:");
		objEnunciado01_1.setN1(objScanner.nextInt());
		
		System.out.println("INFORME O SEGUNDO N�MERO:");
		objEnunciado01_1.setN2(objScanner.nextInt());
		
		objEnunciado01_1.exibirMaior();
		*/
		
		//Enunciado01
		
		/*
	    int n1, n2;
		System.out.println("INFORME O PRIMEIRO N�MERO");
		n1 = objScanner.nextInt();
		
		System.out.println("INFORME O SEGUNDO N�MERO");
		n2 = objScanner.nextInt();
		
		objEnunciado01.exibirMaior(n1, n2);
		*/
		
		//Enunciado02
		
		/*int n1, n2, n3;
		System.out.println("INFORME O PRIMEIRO N�MERO");
		n1 = objScanner.nextInt();
		
		System.out.println("INFORME O SEGUNDO N�MERO");
		n2 = objScanner.nextInt();
		
		System.out.println("INFORME O TERCEIRO N�MERO");
		n3 = objScanner.nextInt();
		
		objEnunciado02.exibirMaior(n1, n2, n3);
		*/
		
		//Enunciado03
		
		
		/*System.out.println("DIGITE A 1� NOTA:");
		objEnunciado03.setnota1(objScanner.nextDouble());
		
		System.out.println("DIGITE A 2� NOTA:");
		objEnunciado03.setnota2(objScanner.nextDouble());
		
		System.out.println("DIGITE A 3� NOTA:");
		objEnunciado03.setnota3(objScanner.nextDouble());
		
		System.out.println("DIGITE A 4� NOTA:");
		objEnunciado03.setnota4(objScanner.nextDouble());
		
		if(objEnunciado03.media1() >=7 ) {
			
			objEnunciado03.CalcularMedia();
		}else {
			
			System.out.println("DIGITE A 5� NOTA:");
			objEnunciado03.setnota5(objScanner.nextDouble());
		}
		objEnunciado03.CalcularMedia2();
		} */
	   
	    //Enunciado04
		
		/*System.out.println("INFORME UM N�MERO");
		objEnunciado04.setN1(objScanner.nextInt());
		
		objEnunciado04.MaiorQueZero();
	*/
		//Enunciado05
	
	   /* System.out.println("INFORME UM N�MERO:");
	    objEnunciado05.setN1(objScanner.nextInt());
	    
	    System.out.println("INFORME OUTRO N�MERO:");
	    objEnunciado05.setN2(objScanner.nextInt());
	    
	    System.out.println("INFORME UM OPERADOR:");
	    objEnunciado05.setOperador(objScanner.next());
	    
	    objEnunciado05.Calculardora();
	    
	    System.out.println("RESULTADO:" + objEnunciado05.getResultado());
	*/
		
	} 
}
